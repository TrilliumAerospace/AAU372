/**
 * NOTE: This is not in use, right now.  It is created to show what the API would look like for arduino
 * #include "trillium.h"
 *
 * void setup() {
 *
 * }
 */

#ifndef TRILLIUM_HOLT_ARDUINO_TRILLIUM_H
#define TRILLIUM_HOLT_ARDUINO_TRILLIUM_H

#include <stdint.h>

#define TR_CH_0 0
#define TR_CH_1 1
#define TR_CH_2 2
#define TR_CH_3 3
#define TR_CH_4 4
#define TR_CH_5 5
#define TR_CH_6 6
#define TR_CH_7 7
//#define TR_CH_8 8
//#define TR_CH_9 9
//#define TR_CH_10 10
//#define TR_CH_11 11
//#define TR_CH_12 12
//#define TR_CH_13 13
//#define TR_CH_14 14
//#define TR_CH_15 15

#define TR_SPEED_HIGH   1
#define TR_SPEED_LOW    2
//#define TR_SPEED_AUTO   3

#define TR_PARITY_EVEN  0
#define TR_PARITY_ODD   1

#define TR_SDI_0    0
#define TR_SDI_1    1
#define TR_SDI_2    2
#define TR_SDI_3    3
#define TR_SDI_ALL  4

#define TR_MSG_GET_LABEL(msg) trillium_util_getbits(msg, 0, 8)
#define TR_MSG_GET_SDI(msg) trillium_util_getbits(msg, 8, 2)
#define TR_MSG_GET_DATA(msg) trillium_util_getbits(msg, 10, 19)
#define TR_MSG_GET_DATA_SSM(msg) trillium_util_getbits(msg, 10, 21)
#define TR_MSG_GET_DATA_SSM_PARITY(msg) trillium_util_getbits(msg, 10, 22)
#define TR_MSG_GET_SIGN(msg) trillium_util_getbits(msg, 28, 1)
#define TR_MSG_GET_SSM(msg) trillium_util_getbits(msg, 29, 2)
#define TR_MSG_GET_PARITY(msg) trillium_util_getbits(msg, 31, 1)

#define TR_MSG_SET_LABEL(msg, data) trillium_util_setbits(msg, data, 0, 8)
#define TR_MSG_SET_SDI(msg, data) trillium_util_setbits(msg, data, 8, 2)
#define TR_MSG_SET_DATA(msg, data) trillium_util_setbits(msg, data, 10, 19)
#define TR_MSG_SET_DATA_SSM(msg, data) trillium_util_setbits(msg, data, 10, 21)
#define TR_MSG_SET_DATA_SSM_PARITY(msg, data) trillium_util_setbits(msg, data, 10, 22)
#define TR_MSG_SET_SIGN(msg, data) trillium_util_setbits(msg, data, 28, 1)
#define TR_MSG_SET_SSM(msg, data) trillium_util_setbits(msg, data, 29, 2)
#define TR_MSG_SET_PARITY(msg, data) trillium_util_setbits(msg, data, 31, 1)

#define TR_DEBUG_DUMP_RXFIFO 1
#define TR_DEBUG_DUMP_REGISTERS 2
#define TR_DEBUG_DUMP_CMD_INIT_TX 3
#define TR_DEBUG_DUMP_CMD_INIT_RX 4
#define TR_DEBUG_DUMP_CMD_TOGGLE_LOOP 5
#define TR_DEBUG_DUMP_CMD_SELF_TEST 6
#define TR_DEBUG_DUMP_CMD_DUMP_RX_FIFO 7
#define TR_DEBUG_DUMP_CMD_DUMP_TX_FIFO 8
#define TR_DEBUG_DUMP_CMD_DUMP_RX_ENABLE 9
#define TR_DEBUG_DUMP_CMD_DUMP_RX_INTERRUPT 10
#define TR_DEBUG_DUMP_CMD_DUMP_SCHEDULES 11
#define TR_DEBUG_DUMP_CMD_CONCENTRATOR_SELF_TEST 12

#define TR_STATUS_OK 0
#define TR_STATUS_NORMAL 0
#define TR_STATUS_BOOTING 1
#define TR_STATUS_BOOT_FAIL 2
#define TR_STATUS_BOOTED 3
#define TR_STATUS_STARTED 4
#define TR_STATUS_STOPPED 5
#define TR_STATUS_SELF_TEST_FAIL 6
#define TR_STATUS_EEPROM_FAIL 7
#define TR_STATUS_HARDWARE_FAIL 8
#define TR_STATUS_SELF_TEST_CONCENTRATOR_FAIL 10
#define TR_STATUS_DIO_HARDWARE_CONFIG_FAIL 11
#define TR_STATUS_DIO_HARDWARE_READ_FAIL 12
#define TR_STATUS_OFF 13
#define TR_STATUS_EEPROM_WRITE 14
#define TR_STATUS_NOT_READY 15
// Used for customer statuses.  Statues 1-199 are reserved for TRILLIUM.
#define TR_STATUS_CUSTOMER 200

#define TR_DIO_0 0
#define TR_DIO_1 1
#define TR_DIO_2 2
#define TR_DIO_3 3
#define TR_DIO_4 4
#define TR_DIO_5 5
#define TR_DIO_6 6
#define TR_DIO_7 7

typedef struct {
  uint8_t in_channel;
  uint8_t in_label;
  uint8_t out_label;
  uint16_t speed_ms;
} TRILLIUM_SCHEDULE_ITEM;

typedef struct {
  uint8_t out_channel;
  uint8_t item_count;
  TRILLIUM_SCHEDULE_ITEM *items;
} TRILLIUM_SCHEDULE;

// Trillium APIs
void trillium_init();
void trillium_debug_init(uint8_t bodval);

// ARINC apis
uint8_t trillium_a429_init(uint16_t bootDelayMS);

uint8_t trillium_a429_start();

uint8_t trillium_a429_stop();

uint8_t trillium_a429_is_started();

uint8_t trillium_a429_get_rx_channels();

uint8_t trillium_a429_get_tx_channels();

uint8_t trillium_a429_configure_tx_channel(uint8_t channel, uint8_t speed, uint8_t parity, uint16_t txRateMS);

uint8_t trillium_a429_configure_rx_channel(uint8_t channel, uint8_t speed, uint8_t parity, uint8_t sdi);

uint8_t trillium_a429_configure_label_filter(uint8_t channel, uint8_t label, uint8_t enabled);

uint8_t trillium_a429_send_label(uint8_t channel, uint32_t label);

uint32_t trillium_a429_read_label(uint8_t channel, uint8_t label);

uint8_t trillium_a429_build_schedule(TRILLIUM_SCHEDULE *schedule);

uint8_t trillium_a429_save_configuration_to_hardware();

uint8_t trillium_a429_clear_configuration_in_hardware();

uint8_t trillium_a429_enable_all_rx_labels_all_channels(uint8_t on);

uint8_t trillium_a429_debug_cmd(uint8_t cmd);

uint8_t trillium_a429_concentrate_all(uint8_t rxLen, uint8_t *rxChanArray, uint8_t txLen, uint8_t *txChanArray);

// STATUS apis
void trillium_status_set_status(uint8_t code, char *msg);

uint8_t trillium_status_get_code();

char *trillium_status_get_message();

void trillium_status_led_loop();

// DIO apis
uint8_t trillium_dio_init();

uint8_t trillium_dio_get_count();

void trillium_dio_set_mode(uint8_t dio, uint8_t mode);

uint8_t trillium_dio_get_mode(uint8_t dio);

uint8_t trillium_dio_get_state(uint8_t dio);

void trillium_dio_set_state(uint8_t dio, uint8_t state);

uint8_t trillium_dio_get_all();

uint8_t trillium_dio_is_on(uint8_t dio, uint8_t states);

uint8_t trillium_dio_is_off(uint8_t dio, uint8_t states);

void trillium_dio_set_all(uint8_t states);

uint8_t trillium_dio_get_config();

void trillium_dio_set_config(uint8_t config);

// SERIAL console apis
uint8_t trillium_serial_init(uint8_t loadDefaultCommands);

void trillium_serial_set_command(char *cmd, char *desc, void (*func)());

void trillium_serial_loop();

// HARDWARE info apis
void trillium_hardware_set_firmware_info(char *version, char *desc);

char *trillium_hardware_get_firmware_version();

char *trillium_hardware_get_firmware_description();

// UTIL apis
void trillium_log(char *buf);

void trillium_logf(char *fmt, ...);

int trillium_util_bcd(int binaryInput);

char *trillium_util_format_binary(uint32_t x);

char *trillium_util_format_binary_size(uint32_t x, uint8_t size);

uint32_t trillium_util_bytes_to_int(uint8_t *bytes4);

uint8_t *trillium_util_int_to_bytes(uint32_t num, uint8_t *bytes4);

uint32_t trillium_util_getbits(uint32_t value, uint8_t offset, uint8_t n);

uint32_t trillium_util_setbits(uint32_t value, uint32_t newValue, uint8_t pos, uint8_t len);

// util hardware apis
uint32_t millis_stamp();

void delayMS(uint32_t ms);

void delayUS(uint32_t us);

float calculate_degrees_over_time(long start, long end, long now, float total_degrees);

// UTIL defines
#define MS_TO_USEC(n) (((uint32_t)n)*1000.0f)
#define SEC_TO_MS(n) ((n)*1000.0f)
#define MIN(a, b) (((a)<(b))?(a):(b))
#define MAX(a, b) (((a)>(b))?(a):(b))
#define trlog trillium_log
#define trlogf trillium_logf

typedef void (*pFunc)();  // pFunc is of Type pointer to a function that takes no argument and returns void

void trillium_schedule(uint8_t position, uint16_t rate, pFunc func);
void trillium_scheduler_loop();

void trillium_delay_ms(uint32_t delay, pFunc loopFunc);

#endif //TRILLIUM_HOLT_ARDUINO_TRILLIUM_H
